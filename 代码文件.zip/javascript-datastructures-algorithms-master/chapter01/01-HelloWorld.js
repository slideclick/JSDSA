function output(t) {
    document.write('<p>' + t + '</p>');
    return;
}

alert('Hello, World!');
console.log('Hello, World!');
output('Hello, World!');